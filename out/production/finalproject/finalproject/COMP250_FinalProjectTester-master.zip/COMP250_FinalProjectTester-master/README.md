# COMP250-FINAL-TESTER
# Disclaimers
- Please only add TEST CODE here, not actual assignment code. If you accidentally pushed your assignment code, please delete ASAP to avoid any inconveniences.
- Otherwise, happy coding and debugging!

# How to Use
- Currently the tester is under construction. As soon as the official tester is out, more tests will be added. 
- However there are some Sodokus we found online. This will save you time from typing.


# How to Start
- You may clone this repo to your Intellij or your preferred IDE. If you aren't familiar with Git, our amazing TA Sasha made a tutorial https://www.youtube.com/playlist?list=PLFvevpoGcNCvjyTjOfPhzqjgb-L_WdX8r
- Worst case scenario, you may also create a new local project, paste all the files on here in it, and add your chessSudoku to the finalproject package.
- You can also add tests if you feel like it! Happy coding and debugging!

# Installing
For IntelliJ IDEA users (recommended)
VCS -> Get from Version Control... -> Paste the URL of this repository

For Eclipse users (if you like suffering)
File -> Import -> Git -> Projects from Git (With Smart Import) -> Clone URI -> paste URL of this repository into the URI box -> Click next a bunch, setting directory at your own discression, Master branch from origin. All else default -> Finish

For both:
Drag your .java files from the assignment into the tester package.
Regularly update the tester (pull the repository) to get any new tests that might have been uploaded.
